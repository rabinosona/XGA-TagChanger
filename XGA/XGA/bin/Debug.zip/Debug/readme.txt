What should you do to make the program work?

Not so much: you just need to enter the data in the file.txt in the following format:

username (usually e-mail) | password | preferrable gametag, preferrable gamertag2, etc (you should separate preferrable tags with , and then the program will separate them and put in the tag-claimer)

You can find example of the file.txt in the program folder.

The program logins into your account, one tag opens one tab, then the program checks all the tags by each one.

The program will work until it'll claim all the tags for all accounts. If the program stops working, then it drops all settings and starts claiming preferred tags again.

And you should install Firefox browser on your machine (the latest version), because my program uses it to enter the site.

The program writes all the errors into the file excepts.txt and saves errors from all sessions.