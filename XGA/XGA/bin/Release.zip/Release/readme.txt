What should you do to make program work?
Not so much: you just need to enter the data in the file.txt in the following format:
username (usually e-mail) | password | preferrable gametag

And you should install Firefox browser on your machine (the latest version), because my program uses it to enter the site.